package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color

// Colors from Figma
val PrimaryOrange = Color(0xFFFF9800) // Replace with the actual hex code
val BackgroundWhite = Color(0xFFFFFFFF)
val AccentBlack = Color(0xFF000000)
val TextGray = Color(0xFF757575) // For subtle text
